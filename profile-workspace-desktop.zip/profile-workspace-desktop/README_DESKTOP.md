# Profile Workspace Desktop — Windows Build Guide

Desktop application built with **Tauri v2** + **React + Vite**.  
The same UI running in production on Replit can be packaged as a native `.exe` / NSIS installer for Windows.

---

## Prerequisites (install on your Windows machine)

| Tool | Version | Download |
|------|---------|----------|
| **Rust + Cargo** | stable (≥ 1.77) | https://rustup.rs |
| **Visual Studio Build Tools** | 2022 | https://visualstudio.microsoft.com/visual-cpp-build-tools/ — select **"Desktop development with C++"** |
| **Node.js** | ≥ 20 LTS | https://nodejs.org |
| **pnpm** | ≥ 9 | `npm i -g pnpm` |
| **WebView2 Runtime** | (usually pre-installed on Win 10/11) | https://developer.microsoft.com/microsoft-edge/webview2 |

Verify your setup:
```powershell
rustc --version   # rustc 1.xx.x
cargo --version   # cargo 1.xx.x
node  --version   # v20.x.x
pnpm  --version   # 9.x.x
```

---

## Project structure (Tauri-relevant files)

```
artifacts/desktop/
├── src/                        # React frontend source
│   ├── lib/tauri-bridge.ts     # Tauri ↔ web detection + IPC wrappers
│   ├── pages/settings.tsx      # API URL config (reads/writes via Tauri store)
│   └── App.tsx                 # Loads API URL on startup (Tauri store or localStorage)
├── src-tauri/
│   ├── Cargo.toml              # Rust dependencies
│   ├── build.rs                # Tauri build script
│   ├── tauri.conf.json         # App name, window, bundle targets
│   ├── icons/                  # App icons (all sizes pre-generated)
│   └── src/main.rs             # Rust entry + save_api_base / load_api_base commands
├── vite.tauri.config.ts        # Vite config for desktop builds (port 1420, no BASE_PATH)
└── package.json                # scripts: tauri:dev, tauri:build
```

---

## Step 1 — Clone and install

```powershell
# Clone the monorepo
git clone <your-repo-url>
cd <repo-root>

# Install all workspace dependencies
pnpm install
```

---

## Step 2 — Set up the backend

The desktop app communicates with an **Express/PostgreSQL backend**.  
Run it locally, or point the app to your deployed API on Replit.

### Option A — Local backend (recommended for offline use)

```powershell
# From repo root
pnpm --filter @workspace/api-server run dev
# Backend now available at http://localhost:8080
```

### Option B — Replit production backend

Skip this step — you'll configure the URL in Settings after launch.

---

## Step 3 — Development mode

```powershell
cd artifacts/desktop

# Start Tauri dev (launches Vite + Rust hot-reload)
pnpm run tauri:dev
```

A native window opens at `http://localhost:1420`.  
Go to **Settings** and set **API Base URL** to `http://localhost:8080` (or your Replit URL).

---

## Step 4 — Production build (`.exe` installer)

```powershell
cd artifacts/desktop

# Build release .exe + NSIS installer
pnpm run tauri:build
```

Output files in `src-tauri/target/release/bundle/`:

```
nsis/
  ProfileWorkspaceDesktop_0.1.0_x64-setup.exe   ← NSIS installer
msi/
  ProfileWorkspaceDesktop_0.1.0_x64_en-US.msi   ← MSI installer
profile-workspace-desktop.exe                    ← Standalone portable exe
```

> **First build takes 5–15 min** (Rust compiles all dependencies).  
> Subsequent builds are much faster thanks to incremental compilation.

---

## Configuring the API URL

When running as a desktop app, the API URL is **persisted to disk** (via `tauri-plugin-store`) and survives app restarts.

1. Open the app → click **Settings** in the sidebar.
2. Enter your backend URL, e.g. `http://localhost:8080` or `https://your-app.replit.app`.
3. Click **Save Config**.

The store file is saved at:
- **Windows**: `%APPDATA%\com.profileworkspace.desktop\settings.json`
- **macOS**: `~/Library/Application Support/com.profileworkspace.desktop/settings.json`
- **Linux**: `~/.config/com.profileworkspace.desktop/settings.json`

---

## Cross-platform builds

| Platform | Command | Output |
|----------|---------|--------|
| Windows | `pnpm run tauri:build` (on Windows) | `.exe`, NSIS `.exe`, `.msi` |
| macOS | `pnpm run tauri:build` (on macOS) | `.app`, `.dmg` |
| Linux | `pnpm run tauri:build` (on Linux) | `.deb`, `.AppImage`, `.rpm` |

> Tauri requires building **on the target OS** — you cannot cross-compile Windows `.exe` from macOS/Linux without a CI setup.

### Building Windows installer from Linux/macOS (CI approach)

Use GitHub Actions with a Windows runner:

```yaml
# .github/workflows/build-desktop.yml
name: Build Desktop
on: [push]
jobs:
  build-windows:
    runs-on: windows-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with: { node-version: 20 }
      - uses: dtolnay/rust-toolchain@stable
      - run: npm i -g pnpm
      - run: pnpm install
      - run: pnpm run tauri:build
        working-directory: artifacts/desktop
      - uses: actions/upload-artifact@v4
        with:
          name: windows-installer
          path: artifacts/desktop/src-tauri/target/release/bundle/nsis/*.exe
```

---

## Troubleshooting

| Error | Fix |
|-------|-----|
| `error: linker 'link.exe' not found` | Install Visual Studio Build Tools with **C++ Desktop** workload |
| `WebView2 not found` | Install [WebView2 Runtime](https://developer.microsoft.com/microsoft-edge/webview2) |
| `thread 'main' panicked — Could not initialize store` | Delete `%APPDATA%\com.profileworkspace.desktop\settings.json` and restart |
| API calls fail | Check API Base URL in Settings; ensure backend is running |
| NSIS installer missing | Run `cargo install tauri-cli` and retry; or check `src-tauri/target/release/bundle/` |

---

## Scripts reference

```powershell
# From artifacts/desktop directory:

pnpm run tauri:dev     # Dev mode (hot reload)
pnpm run tauri:build   # Production build → installers
pnpm run vite:tauri    # Vite only (for debugging frontend separately)
pnpm run dev           # Web mode (Replit preview, no Tauri runtime)
pnpm run build         # Web-mode static build
```

---

## Architecture notes

- **`tauri-bridge.ts`** — detects `__TAURI_INTERNALS__` on `window` to know if running in desktop or browser. All API URL load/save goes through this bridge.
- **`save_api_base` / `load_api_base`** — Rust IPC commands exposed via Tauri's `invoke_handler`. They use `tauri-plugin-store` to persist settings to a JSON file on disk.
- **`vite.tauri.config.ts`** — separate Vite config with `port: 1420` (required by Tauri), no `PORT`/`BASE_PATH` env vars, and direct source alias for `@workspace/api-client-react`.
