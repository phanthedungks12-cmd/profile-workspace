import { useEffect, useState } from "react";
import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { setBaseUrl } from "@workspace/api-client-react";
import { loadApiBaseUrl } from "@/lib/tauri-bridge";

import { Layout } from "@/components/layout";
import ProfilesPage from "@/pages/profiles";
import JobsPage from "@/pages/jobs";
import AuditLogsPage from "@/pages/audit-logs";
import SettingsPage from "@/pages/settings";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
      staleTime: 5000,
    }
  }
});

function AppRouter() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={ProfilesPage} />
        <Route path="/jobs" component={JobsPage} />
        <Route path="/audit-logs" component={AuditLogsPage} />
        <Route path="/settings" component={SettingsPage} />
        
        <Route>
          <div className="flex items-center justify-center h-full text-muted-foreground font-mono">
            404 | View Not Found
          </div>
        </Route>
      </Switch>
    </Layout>
  );
}

function App() {
  const [isInitialized, setIsInitialized] = useState(false);

  useEffect(() => {
    // Load API URL from Tauri persistent store (desktop) or localStorage (web).
    // Empty string = use relative /api paths, which works in Replit preview.
    loadApiBaseUrl().then((url) => {
      if (url) setBaseUrl(url);
      setIsInitialized(true);
    });
  }, []);

  if (!isInitialized) return null;

  return (
    <QueryClientProvider client={queryClient}>
      <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
        <AppRouter />
      </WouterRouter>
      <Toaster />
    </QueryClientProvider>
  );
}

export default App;
