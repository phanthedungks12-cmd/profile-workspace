import { useToast } from "@/hooks/use-toast";
import { motion, AnimatePresence } from "framer-motion";
import { X, CheckCircle2, AlertCircle } from "lucide-react";

export function Toaster() {
  const { toasts } = useToast();

  return (
    <div className="fixed bottom-4 right-4 z-50 flex flex-col gap-2 w-full max-w-sm pointer-events-none">
      <AnimatePresence>
        {toasts.map((toast, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20, scale: 0.95 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
            className={`
              pointer-events-auto flex items-start gap-3 p-4 rounded-xl border shadow-2xl glass-panel
              ${toast.variant === "destructive" ? "border-destructive/50 bg-destructive/10" : "border-primary/20 bg-card/80"}
            `}
          >
            {toast.variant === "destructive" ? (
              <AlertCircle className="w-5 h-5 text-destructive shrink-0 mt-0.5" />
            ) : (
              <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5" />
            )}
            <div className="flex-1 flex flex-col gap-1">
              {toast.title && <h3 className="font-semibold text-sm text-foreground">{toast.title}</h3>}
              {toast.description && <p className="text-sm text-muted-foreground">{toast.description}</p>}
            </div>
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}
