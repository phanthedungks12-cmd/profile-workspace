import { Link, useRoute } from "wouter";
import { Users, Briefcase, ScrollText, Settings, LayoutDashboard } from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  { href: "/", label: "Profiles", icon: Users },
  { href: "/jobs", label: "Automation Jobs", icon: Briefcase },
  { href: "/audit-logs", label: "Audit Logs", icon: ScrollText },
  { href: "/settings", label: "Settings", icon: Settings },
];

function NavItem({ href, label, icon: Icon }: { href: string; label: string; icon: any }) {
  const [isActive] = useRoute(href);
  
  return (
    <Link 
      href={href} 
      className={cn(
        "flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
        isActive 
          ? "bg-primary/10 text-primary font-medium" 
          : "text-muted-foreground hover:bg-secondary/50 hover:text-foreground"
      )}
    >
      <Icon className={cn("w-5 h-5 transition-transform duration-200", isActive ? "scale-110" : "group-hover:scale-110")} />
      <span>{label}</span>
      {isActive && (
        <div className="ml-auto w-1.5 h-1.5 rounded-full bg-primary shadow-[0_0_8px_rgba(79,70,229,0.8)]" />
      )}
    </Link>
  );
}

export function Layout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex h-screen bg-background overflow-hidden selection:bg-primary/30">
      <aside className="w-64 border-r border-border/50 bg-sidebar/50 backdrop-blur-xl flex flex-col z-10 relative">
        {/* Subtle glow effect behind sidebar */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden pointer-events-none -z-10">
          <div className="absolute -top-24 -left-24 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
        </div>
        
        <div className="h-16 flex items-center px-6 border-b border-border/50">
          <LayoutDashboard className="w-6 h-6 text-primary mr-3" />
          <h1 className="font-display font-bold text-lg tracking-wide text-foreground">Profile<span className="text-primary">Workspace</span></h1>
        </div>
        
        <nav className="flex-1 px-3 py-6 flex flex-col gap-2 overflow-y-auto">
          {navItems.map((item) => (
            <NavItem key={item.href} {...item} />
          ))}
        </nav>
        
        <div className="p-4 border-t border-border/50">
          <div className="glass-panel p-4 rounded-xl flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center text-primary font-bold text-sm">
              AD
            </div>
            <div>
              <div className="text-sm font-medium">Local Admin</div>
              <div className="text-xs text-muted-foreground">Workspace active</div>
            </div>
          </div>
        </div>
      </aside>
      
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative">
        <div className="flex-1 overflow-y-auto p-6 md:p-8 lg:p-10 relative z-10">
          {children}
        </div>
      </main>
    </div>
  );
}
