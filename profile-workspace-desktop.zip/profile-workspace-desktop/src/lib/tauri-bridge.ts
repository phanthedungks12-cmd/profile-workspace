/**
 * Tauri Bridge — detects Tauri runtime and wraps IPC commands.
 * Falls back to localStorage when running in a browser / Replit preview.
 */

export const isTauri = (): boolean =>
  typeof window !== "undefined" && "__TAURI_INTERNALS__" in window;

/**
 * Load the saved API Base URL.
 * - Tauri: reads from the persistent store via Rust command.
 * - Web:   reads from localStorage.
 */
export async function loadApiBaseUrl(): Promise<string> {
  if (isTauri()) {
    try {
      const { invoke } = await import("@tauri-apps/api/core");
      const url = await invoke<string | null>("load_api_base");
      return url ?? "";
    } catch {
      return "";
    }
  }
  return localStorage.getItem("apiBaseUrl") ?? "";
}

/**
 * Persist the API Base URL.
 * - Tauri: writes to the persistent store (survives app restarts).
 * - Web:   writes to localStorage.
 */
export async function saveApiBaseUrl(url: string): Promise<void> {
  if (isTauri()) {
    try {
      const { invoke } = await import("@tauri-apps/api/core");
      await invoke("save_api_base", { value: url });
    } catch (err) {
      console.error("[tauri-bridge] save_api_base failed:", err);
    }
  } else {
    if (url.trim()) {
      localStorage.setItem("apiBaseUrl", url.trim());
    } else {
      localStorage.removeItem("apiBaseUrl");
    }
  }
}
