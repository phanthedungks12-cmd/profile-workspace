import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { useHealthCheck, setBaseUrl } from "@workspace/api-client-react";
import { Server, Save, CheckCircle2, XCircle, Globe, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { loadApiBaseUrl, saveApiBaseUrl, isTauri } from "@/lib/tauri-bridge";

export default function SettingsPage() {
  const [url, setUrl] = useState("");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: health, isLoading, isError, refetch } = useHealthCheck();

  useEffect(() => {
    loadApiBaseUrl().then((saved) => setUrl(saved));
  }, []);

  const handleSave = async () => {
    const trimmed = url.trim();
    if (trimmed) {
      try {
        new URL(trimmed);
      } catch {
        toast({
          title: "Invalid URL",
          description: "Enter a valid HTTP/HTTPS URL, or leave empty to use relative /api paths.",
          variant: "destructive",
        });
        return;
      }
    }

    setSaving(true);
    try {
      await saveApiBaseUrl(trimmed);
      setBaseUrl(trimmed);
      queryClient.clear();
      refetch();
      toast({
        title: "Settings Saved",
        description: trimmed
          ? `API Base URL updated to ${trimmed}`
          : "Using default relative API paths.",
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 max-w-3xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Settings</h1>
        <p className="text-muted-foreground mt-1">Configure desktop application preferences.</p>
      </div>

      {/* Runtime badge */}
      <div className="flex items-center gap-2 text-xs font-mono text-muted-foreground/70">
        <Monitor className="w-3.5 h-3.5" />
        Running in: <span className="text-primary">{isTauri() ? "Tauri Desktop" : "Web / Replit Preview"}</span>
      </div>

      <div className="glass-panel rounded-3xl p-8 space-y-8">

        {/* Connection Status */}
        <div className={`p-5 rounded-2xl border flex items-start gap-4 transition-colors ${
          isLoading ? "bg-secondary/30 border-border/50" :
          isError   ? "bg-destructive/10 border-destructive/30" :
                      "bg-emerald-500/10 border-emerald-500/30"
        }`}>
          {isLoading ? (
            <Server className="w-8 h-8 text-muted-foreground animate-pulse mt-1" />
          ) : isError ? (
            <XCircle className="w-8 h-8 text-destructive mt-1" />
          ) : (
            <CheckCircle2 className="w-8 h-8 text-emerald-400 mt-1" />
          )}
          <div className="flex-1">
            <h3 className="font-semibold text-lg mb-1">
              {isLoading ? "Checking connection…" : isError ? "Connection Failed" : "Connected to Backend"}
            </h3>
            {health && (
              <div className="text-sm font-mono text-muted-foreground mt-2 bg-background/50 p-3 rounded-xl border border-border/50">
                {JSON.stringify(health, null, 2)}
              </div>
            )}
            {isError && (
              <p className="text-sm text-destructive mt-1">
                Ensure the backend server is running at the configured URL.
              </p>
            )}
          </div>
        </div>

        {/* API Base URL */}
        <div className="space-y-2">
          <label className="flex items-center gap-2 text-sm font-semibold text-foreground">
            <Globe className="w-4 h-4 text-primary" /> API Base URL
          </label>
          <p className="text-xs text-muted-foreground">
            {isTauri()
              ? "Desktop mode: point this at your running backend, e.g. http://127.0.0.1:8080. Persisted across restarts."
              : "Web mode: leave empty to use relative /api paths (Replit proxy). Set a full URL only when your backend is on a different host."}
          </p>
          <div className="flex gap-3 mt-2">
            <Input
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder={isTauri() ? "http://127.0.0.1:8080" : "(empty = use /api proxy)"}
              className="font-mono glass-input text-lg"
              onKeyDown={(e) => e.key === "Enter" && handleSave()}
            />
            <Button onClick={handleSave} size="lg" className="shrink-0 px-8" disabled={saving}>
              <Save className="w-4 h-4 mr-2" /> {saving ? "Saving…" : "Save Config"}
            </Button>
          </div>
        </div>

      </div>
    </motion.div>
  );
}
