import { motion } from "framer-motion";
import { useListJobs, type AutomationJob } from "@workspace/api-client-react";
import { Terminal, Clock, PlayCircle, CheckCircle2, XCircle } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { formatDate } from "@/lib/utils";

function JobStatusBadge({ status }: { status: string }) {
  switch (status) {
    case "queued":
      return <Badge variant="outline" className="border-muted-foreground/30 text-muted-foreground bg-secondary/50"><Clock className="w-3 h-3 mr-1" /> Queued</Badge>;
    case "running":
      return <Badge variant="default" className="animate-pulse bg-blue-500/20 text-blue-400"><PlayCircle className="w-3 h-3 mr-1" /> Running</Badge>;
    case "succeeded":
      return <Badge variant="success"><CheckCircle2 className="w-3 h-3 mr-1" /> Succeeded</Badge>;
    case "failed":
      return <Badge variant="destructive"><XCircle className="w-3 h-3 mr-1" /> Failed</Badge>;
    default:
      return <Badge variant="secondary">{status}</Badge>;
  }
}

export default function JobsPage() {
  const { data: jobs, isLoading } = useListJobs();

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Automation Jobs</h1>
        <p className="text-muted-foreground mt-1">Monitor background tasks and profile operations.</p>
      </div>

      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border/50 bg-secondary/30">
                <th className="p-4 font-semibold text-sm text-muted-foreground">Job Details</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Status</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Timeline</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Result/Error</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/30">
              {isLoading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    <td className="p-4"><div className="h-10 bg-secondary/50 animate-pulse rounded-lg w-48" /></td>
                    <td className="p-4"><div className="h-6 bg-secondary/50 animate-pulse rounded-full w-24" /></td>
                    <td className="p-4"><div className="h-10 bg-secondary/50 animate-pulse rounded-lg w-32" /></td>
                    <td className="p-4"><div className="h-6 bg-secondary/50 animate-pulse rounded-lg w-full" /></td>
                  </tr>
                ))
              ) : jobs?.length === 0 ? (
                <tr>
                  <td colSpan={4} className="p-12 text-center text-muted-foreground">
                    <Terminal className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    No jobs have been executed yet.
                  </td>
                </tr>
              ) : (
                jobs?.map((job: AutomationJob) => (
                  <motion.tr 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    key={job.id} 
                    className="hover:bg-secondary/20 transition-colors group"
                  >
                    <td className="p-4">
                      <div className="font-mono text-sm text-primary/90 font-medium mb-1">{job.job_type}</div>
                      <div className="text-xs text-muted-foreground font-mono truncate max-w-[200px]" title={job.profile_id}>
                        Prof: {job.profile_id.split('-')[0]}...
                      </div>
                    </td>
                    <td className="p-4">
                      <JobStatusBadge status={job.status} />
                    </td>
                    <td className="p-4 text-xs text-muted-foreground space-y-1">
                      <div><span className="opacity-60">Created:</span> {formatDate(job.created_at)}</div>
                      {job.finished_at && <div><span className="opacity-60">Finished:</span> {formatDate(job.finished_at)}</div>}
                    </td>
                    <td className="p-4 max-w-xs">
                      {job.error_message ? (
                        <div className="text-xs text-destructive bg-destructive/10 p-2 rounded border border-destructive/20 line-clamp-2">
                          {job.error_message}
                        </div>
                      ) : job.result_path ? (
                        <div className="text-xs font-mono text-emerald-400 bg-emerald-500/10 p-2 rounded border border-emerald-500/20 truncate">
                          {job.result_path}
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
