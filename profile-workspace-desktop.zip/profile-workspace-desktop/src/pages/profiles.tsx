import { useState } from "react";
import { motion } from "framer-motion";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { 
  useListProfiles, 
  useCreateProfile, 
  useDeleteProfile,
  useCreateJob,
  type Profile 
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Plus, Chrome, Trash2, ShieldCheck, DatabaseBackup, Activity, MoreVertical, Search, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { formatDate } from "@/lib/utils";

const profileSchema = z.object({
  name: z.string().min(2, "Name must be at least 2 characters"),
  description: z.string().optional(),
  browser_channel: z.string().default("chrome"),
  proxy_url: z.string().optional(),
  home_url: z.string().optional(),
  storage_path: z.string().optional(),
});

type ProfileFormValues = z.infer<typeof profileSchema>;

export default function ProfilesPage() {
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [search, setSearch] = useState("");
  
  const { data: profiles, isLoading, error } = useListProfiles();
  const createProfile = useCreateProfile();
  const deleteProfile = useDeleteProfile();
  const createJob = useCreateJob();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const { register, handleSubmit, reset, formState: { errors } } = useForm<ProfileFormValues>({
    resolver: zodResolver(profileSchema),
    defaultValues: { browser_channel: "chrome" }
  });

  const onSubmit = (data: ProfileFormValues) => {
    createProfile.mutate({ data }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
        setIsCreateOpen(false);
        reset();
        toast({ title: "Profile created", description: "New profile has been added to the workspace." });
      },
      onError: (err: any) => {
        toast({ title: "Error", description: err.message, variant: "destructive" });
      }
    });
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this profile?")) {
      deleteProfile.mutate({ profileId: id }, {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/profiles"] });
          toast({ title: "Profile deleted" });
        }
      });
    }
  };

  const handleRunJob = (profileId: string, jobType: "profile_validation" | "profile_backup" | "network_check") => {
    createJob.mutate({ data: { profile_id: profileId, job_type: jobType } }, {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: ["/api/jobs"] });
        toast({ title: "Job queued", description: `Started ${jobType.replace('_', ' ')}` });
      }
    });
  };

  const filteredProfiles = profiles?.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    (p.description && p.description.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 max-w-7xl mx-auto">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Profiles</h1>
          <p className="text-muted-foreground mt-1">Manage and automate your browser profiles.</p>
        </div>
        <Button onClick={() => setIsCreateOpen(true)} className="w-full sm:w-auto">
          <Plus className="w-4 h-4 mr-2" /> New Profile
        </Button>
      </div>

      <div className="flex items-center gap-4 bg-card/50 border border-border/50 p-2 rounded-2xl backdrop-blur-sm">
        <div className="relative flex-1">
          <Search className="w-5 h-5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" />
          <Input 
            placeholder="Search profiles..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 border-none bg-transparent focus-visible:ring-0 shadow-none h-10"
          />
        </div>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4, 5, 6].map(i => (
            <div key={i} className="h-64 rounded-2xl bg-card/50 animate-pulse border border-border/50" />
          ))}
        </div>
      ) : error ? (
        <div className="glass-panel p-8 text-center rounded-2xl flex flex-col items-center">
          <AlertCircle className="w-12 h-12 text-destructive mb-4" />
          <h3 className="text-xl font-bold">Failed to load profiles</h3>
          <p className="text-muted-foreground mt-2">Check your API connection in Settings.</p>
        </div>
      ) : filteredProfiles?.length === 0 ? (
        <div className="glass-panel p-16 text-center rounded-3xl border-dashed border-2 border-border/50 flex flex-col items-center justify-center">
          <div className="w-20 h-20 bg-primary/10 rounded-full flex items-center justify-center mb-6">
            <Chrome className="w-10 h-10 text-primary opacity-80" />
          </div>
          <h3 className="text-2xl font-bold text-foreground mb-2">No profiles found</h3>
          <p className="text-muted-foreground max-w-md mx-auto mb-8">
            Create your first browser profile to start managing isolated environments and running automation tasks.
          </p>
          <Button onClick={() => setIsCreateOpen(true)} size="lg">
            Create Profile
          </Button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
          {filteredProfiles?.map((profile: Profile, idx) => (
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.05 }}
              key={profile.id} 
              className="glass-panel rounded-2xl p-6 group hover:border-primary/30 transition-all duration-300 relative overflow-hidden"
            >
              {/* Card background glow */}
              <div className="absolute -top-24 -right-24 w-48 h-48 bg-primary/10 rounded-full blur-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
              
              <div className="flex justify-between items-start mb-4 relative z-10">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-secondary flex items-center justify-center shadow-inner">
                    <Chrome className="w-6 h-6 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-bold text-lg leading-tight text-foreground group-hover:text-primary transition-colors">{profile.name}</h3>
                    <div className="flex items-center gap-2 mt-1">
                      <span className="text-xs text-muted-foreground font-medium uppercase tracking-wider">{profile.browser_channel}</span>
                      <div className="w-1 h-1 rounded-full bg-border" />
                      <Badge variant={profile.status === "active" ? "success" : "secondary"} className="h-5 text-[10px]">
                        {profile.status}
                      </Badge>
                    </div>
                  </div>
                </div>
                
                <button 
                  onClick={() => handleDelete(profile.id)}
                  className="p-2 text-muted-foreground hover:text-destructive hover:bg-destructive/10 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                  title="Delete Profile"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
              
              {profile.description && (
                <p className="text-sm text-muted-foreground line-clamp-2 mb-6 h-10 relative z-10">
                  {profile.description}
                </p>
              )}
              {!profile.description && <div className="h-10 mb-6" />}

              <div className="grid grid-cols-3 gap-2 relative z-10">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-16 flex flex-col gap-2 items-center justify-center border-border/50 bg-background/30 hover:bg-primary/10 hover:border-primary/30 hover:text-primary"
                  onClick={() => handleRunJob(profile.id, "profile_validation")}
                >
                  <ShieldCheck className="w-4 h-4" />
                  <span className="text-[10px] uppercase tracking-wider">Validate</span>
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-16 flex flex-col gap-2 items-center justify-center border-border/50 bg-background/30 hover:bg-primary/10 hover:border-primary/30 hover:text-primary"
                  onClick={() => handleRunJob(profile.id, "profile_backup")}
                >
                  <DatabaseBackup className="w-4 h-4" />
                  <span className="text-[10px] uppercase tracking-wider">Backup</span>
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="h-16 flex flex-col gap-2 items-center justify-center border-border/50 bg-background/30 hover:bg-primary/10 hover:border-primary/30 hover:text-primary"
                  onClick={() => handleRunJob(profile.id, "network_check")}
                >
                  <Activity className="w-4 h-4" />
                  <span className="text-[10px] uppercase tracking-wider">Network</span>
                </Button>
              </div>
              
              <div className="mt-4 pt-4 border-t border-border/30 text-xs text-muted-foreground/70 flex justify-between relative z-10">
                <span>Updated {formatDate(profile.updated_at)}</span>
              </div>
            </motion.div>
          ))}
        </div>
      )}

      <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
        <DialogHeader>
          <DialogTitle>Create New Profile</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 mt-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Profile Name *</label>
              <Input {...register("name")} placeholder="e.g. Marketing Ops" className="glass-input" />
              {errors.name && <p className="text-xs text-destructive">{errors.name.message}</p>}
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Browser Channel</label>
              <select 
                {...register("browser_channel")}
                className="flex h-11 w-full rounded-xl border border-border/50 bg-background/50 px-3 py-2 text-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:border-primary backdrop-blur-sm"
              >
                <option value="chrome">Chrome</option>
                <option value="firefox">Firefox</option>
                <option value="edge">Edge</option>
              </select>
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Description</label>
            <Input {...register("description")} placeholder="Purpose of this profile..." className="glass-input" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Proxy URL</label>
              <Input {...register("proxy_url")} placeholder="http://user:pass@ip:port" className="glass-input" />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">Home URL</label>
              <Input {...register("home_url")} placeholder="https://example.com" className="glass-input" />
            </div>
          </div>
          
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Custom Storage Path</label>
            <Input {...register("storage_path")} placeholder="/absolute/path/to/data" className="glass-input" />
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <Button type="button" variant="ghost" onClick={() => setIsCreateOpen(false)}>Cancel</Button>
            <Button type="submit" isLoading={createProfile.isPending}>Create Profile</Button>
          </div>
        </form>
      </Dialog>
    </motion.div>
  );
}
