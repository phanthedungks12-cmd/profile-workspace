import { motion } from "framer-motion";
import { useListAuditLogs, type AuditLog } from "@workspace/api-client-react";
import { ScrollText, User, Tag, Hash } from "lucide-react";
import { formatDate } from "@/lib/utils";

export default function AuditLogsPage() {
  const { data: logs, isLoading } = useListAuditLogs({ limit: 50 });

  return (
    <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-8 max-w-7xl mx-auto">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Audit Logs</h1>
        <p className="text-muted-foreground mt-1">System activity and security events trail.</p>
      </div>

      <div className="glass-panel rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-border/50 bg-secondary/30">
                <th className="p-4 font-semibold text-sm text-muted-foreground w-48">Timestamp</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Action</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Actor</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Target</th>
                <th className="p-4 font-semibold text-sm text-muted-foreground">Metadata</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border/30">
              {isLoading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    <td className="p-4"><div className="h-5 bg-secondary/50 animate-pulse rounded w-32" /></td>
                    <td className="p-4"><div className="h-5 bg-secondary/50 animate-pulse rounded w-40" /></td>
                    <td className="p-4"><div className="h-5 bg-secondary/50 animate-pulse rounded w-24" /></td>
                    <td className="p-4"><div className="h-5 bg-secondary/50 animate-pulse rounded w-32" /></td>
                    <td className="p-4"><div className="h-5 bg-secondary/50 animate-pulse rounded w-full" /></td>
                  </tr>
                ))
              ) : logs?.length === 0 ? (
                <tr>
                  <td colSpan={5} className="p-12 text-center text-muted-foreground">
                    <ScrollText className="w-12 h-12 mx-auto mb-3 opacity-20" />
                    No audit logs found.
                  </td>
                </tr>
              ) : (
                logs?.map((log: AuditLog) => (
                  <motion.tr 
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    key={log.id} 
                    className="hover:bg-secondary/20 transition-colors"
                  >
                    <td className="p-4 text-sm text-muted-foreground whitespace-nowrap">
                      {formatDate(log.created_at)}
                    </td>
                    <td className="p-4">
                      <div className="inline-flex items-center px-2.5 py-1 rounded-md text-xs font-mono font-medium bg-primary/10 text-primary border border-primary/20">
                        {log.action}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex items-center gap-2 text-sm text-foreground">
                        <User className="w-3.5 h-3.5 text-muted-foreground" />
                        {log.actor_email}
                      </div>
                    </td>
                    <td className="p-4">
                      <div className="flex flex-col gap-1 text-sm">
                        <div className="flex items-center gap-1.5 text-muted-foreground">
                          <Tag className="w-3 h-3" /> <span className="uppercase text-[10px] tracking-wider">{log.target_type}</span>
                        </div>
                        <div className="flex items-center gap-1.5 font-mono text-xs text-foreground/80 truncate max-w-[150px]">
                          <Hash className="w-3 h-3 text-muted-foreground" /> {log.target_id.split('-')[0]}...
                        </div>
                      </div>
                    </td>
                    <td className="p-4">
                      {log.meta ? (
                        <div className="text-xs font-mono text-muted-foreground bg-background/50 p-2 rounded border border-border/50 max-h-16 overflow-y-auto w-full max-w-md custom-scrollbar">
                          {JSON.stringify(log.meta)}
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">—</span>
                      )}
                    </td>
                  </motion.tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </motion.div>
  );
}
