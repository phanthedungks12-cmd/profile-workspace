# Profile Workspace Desktop — Standalone Build Guide

Thư mục này **hoàn toàn độc lập**. Bạn chỉ cần tải về thư mục `desktop/` này và build ngay trên Windows — không cần bất kỳ file nào từ root monorepo.

---

## Yêu cầu cài đặt trên máy Windows

### 1. Rust + Visual Studio Build Tools (bắt buộc cho Tauri)

```powershell
# Cài Rust (chọn "1) Proceed with standard installation")
winget install Rustlang.Rustup

# Sau khi cài xong, khởi động lại terminal rồi chạy:
rustup target add x86_64-pc-windows-msvc
```

Nếu chưa có Visual Studio Build Tools:
```powershell
winget install Microsoft.VisualStudio.2022.BuildTools
# Trong installer, chọn "Desktop development with C++"
```

### 2. Node.js

```powershell
winget install OpenJS.NodeJS.LTS
```

### 3. pnpm

```powershell
npm install -g pnpm
```

### 4. WebView2 (thường đã có sẵn trên Windows 10/11)

Nếu chưa có: https://developer.microsoft.com/microsoft-edge/webview2/

---

## Cấu trúc thư mục (standalone, không cần file ngoài)

```
desktop/
├── src/
│   ├── vendor/
│   │   └── api-client-react/      ← API client đã được vendor sẵn
│   │       ├── index.ts
│   │       ├── custom-fetch.ts
│   │       └── generated/
│   │           ├── api.ts         ← React Query hooks
│   │           └── api.schemas.ts ← TypeScript types
│   ├── lib/
│   │   └── tauri-bridge.ts        ← Tauri IPC bridge
│   ├── pages/
│   │   ├── profiles.tsx
│   │   ├── jobs.tsx
│   │   ├── audit-logs.tsx
│   │   └── settings.tsx
│   └── App.tsx
├── src-tauri/
│   ├── src/main.rs                ← Rust entry point
│   ├── Cargo.toml
│   ├── tauri.conf.json
│   └── icons/
├── package.json                   ← Tất cả versions đã được pin cụ thể
├── tsconfig.json                  ← Standalone, không extends file ngoài
├── vite.tauri.config.ts           ← Vite config cho Tauri build
└── vite.config.ts                 ← Vite config cho Replit web (bỏ qua khi build Tauri)
```

---

## Build Windows Installer (.exe)

```powershell
# 1. Vào thư mục desktop
cd path\to\desktop

# 2. Cài dependencies
pnpm install

# 3. Build installer
pnpm run tauri:build
```

**Output:** `src-tauri\target\release\bundle\nsis\ProfileWorkspaceDesktop_0.1.0_x64-setup.exe`

---

## Dev Mode (cửa sổ native với hot-reload)

```powershell
pnpm install

# Chạy dev mode (mở cửa sổ Windows native)
pnpm run tauri:dev
```

---

## Cấu hình API Base URL

Sau khi cài đặt và chạy app, vào **Settings**:

- **Để trống**: App kết nối tới `http://localhost:8080` (nếu chạy API server cục bộ)
- **Nhập URL đầy đủ**: Ví dụ `https://your-api-server.com` để kết nối tới server từ xa

Cấu hình được lưu tại `%APPDATA%\com.profileworkspace.desktop\settings.json`.

---

## Lỗi thường gặp

| Lỗi | Giải pháp |
|-----|-----------|
| `error: linker 'link.exe' not found` | Cài Visual Studio Build Tools + "Desktop development with C++" |
| `WebView2 not found` | Cài Microsoft Edge WebView2 Runtime |
| `VCRUNTIME140.dll not found` | Cài Microsoft Visual C++ Redistributable |
| `pnpm: command not found` | Chạy `npm install -g pnpm` trong PowerShell (admin) |

---

## Không cần tải về từ monorepo

Thư mục này **không phụ thuộc vào**:
- `../../pnpm-workspace.yaml` — đã pin tất cả versions trong `package.json`
- `../../tsconfig.base.json` — `tsconfig.json` đã standalone hoàn toàn
- `../../lib/api-client-react/` — source đã được copy vào `src/vendor/api-client-react/`

Bạn chỉ cần copy thư mục `desktop/` này sang máy Windows và chạy `pnpm install && pnpm run tauri:build`.
