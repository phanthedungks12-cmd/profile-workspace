#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

use tauri_plugin_store::StoreExt;

/// Save the API Base URL into the persistent store.
#[tauri::command]
fn save_api_base(app: tauri::AppHandle, value: String) -> Result<(), String> {
    let store = app
        .store("settings.json")
        .map_err(|e| e.to_string())?;
    store.set("api_base", serde_json::Value::String(value));
    store.save().map_err(|e| e.to_string())?;
    Ok(())
}

/// Load the API Base URL from the persistent store.
/// Returns None if not yet configured.
#[tauri::command]
fn load_api_base(app: tauri::AppHandle) -> Result<Option<String>, String> {
    let store = app
        .store("settings.json")
        .map_err(|e| e.to_string())?;
    Ok(store
        .get("api_base")
        .and_then(|v| v.as_str().map(|s| s.to_string())))
}

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_store::Builder::default().build())
        .invoke_handler(tauri::generate_handler![save_api_base, load_api_base])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
